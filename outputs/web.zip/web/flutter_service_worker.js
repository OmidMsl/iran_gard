'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';
const RESOURCES = {
  "version.json": "d20dc080a9af3dc496cb471ccef49e48",
"index.html": "34bd036b6ce688ae8439a0d4ad3e13bf",
"/": "34bd036b6ce688ae8439a0d4ad3e13bf",
"main.dart.js": "b869c131841f928afc3c8e3d866b587e",
"icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"manifest.json": "c24d8fadf44221ceb288f652f0b90419",
"favicon.png": "5dcef449791fa27946b3d35ad8803796",
"assets/FontManifest.json": "36204c997e79f16f69bc78423e343f26",
"assets/fonts/MaterialIcons-Regular.otf": "4e6447691c9509f7acdbf8a931a85ca1",
"assets/fonts/IranGardIcons.ttf": "a6bd52154f958d9598d64e06b99fd218",
"assets/fonts/IRANSansNum.ttf": "669177836d145526c0238fb731f36246",
"assets/AssetManifest.json": "0ddf8d36fa11783010db70df68e5379d",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "6d342eb68f170c97609e9da345464e5e",
"assets/NOTICES": "ccd4df4fedf81944dd9ed75d55322797",
"assets/images/chalkandi_1.jpg": "1d613c4fd42635dab69ddaff3c3a924e",
"assets/images/loot_2.jpg": "3f3e0361cc8ac4d60b30f1930e837f9f",
"assets/images/dezful_tourism.jpg": "ee93d9ddd158106d3b8250571b1c83bf",
"assets/images/chalkandi_3.jpg": "f12407b771d538784fee0d0ab507c9c6",
"assets/images/iran_tours.jpg": "cc71a69d4ae25096594c6b0d4bcb286a",
"assets/images/shahyoun_3.jpg": "2dfd0eacdd8fae449fd4cd97589323e8",
"assets/images/ad_2.png": "0b6a7f115c3a074ad45e7b283f76df78",
"assets/images/no_image_user.png": "fcea91823e4d03fcc771f73fa8761775",
"assets/images/circle_off.png": "3628f0cdcf08dd901feb034513f2e2b8",
"assets/images/shevi_1.jpeg": "5f71c8effbf9991c3e1739afe6f4023c",
"assets/images/shahyoun_2.jpg": "42d260b8331cadd0889149466ef7af65",
"assets/images/shevi_2.jpeg": "8fa8f044fde09060385fc894535034ae",
"assets/images/shahyoun_1.jpg": "d7bb4d2ea8e7d077705a9cc5a8b4df3f",
"assets/images/shevi_4.jpeg": "b781f52629a91fbabdc5cad4a1f12650",
"assets/images/gallery.png": "87466c471372991446adf45314c3038f",
"assets/images/chalkandi_2.jpg": "ab82de21f1e16ead3843a03b7771a6d2",
"assets/images/defImage.png": "d4a5ab01c9ea13dd2ede8b0fa6c58ac1",
"assets/images/shevi_3.jpg": "5ca281a321954d3bbcd53239542c86f1",
"assets/images/is_online.png": "9a9a2af90db74947f06e18f61acca2d1",
"assets/images/find_by_location.png": "090f93fae062292ff5cdabba4ee6f6ef",
"assets/images/loading-screen.gif": "c7cce308690c435002dfedee6889d135",
"assets/images/loot_1.jpg": "609345a2022ac53dfffc78d2d10054ee",
"assets/images/ad_1.jpg": "bd47e1378205f4336e8b1d5c89a4d0fe",
"assets/images/circle_on.png": "12b42e5239c21b30f932275670b6c842",
"assets/images/find_on_map.jpg": "65c7bd541d892fc6bef43b91f6e3e469",
"assets/images/users/user_4": "2e52f2e2242837f24109656d82c03ca2",
"assets/images/users/user_2": "db54c61f1441d6f7e2b5c2b80a6fd752",
"assets/images/users/user_3": "8a07355f01cab890006736d4334dab90",
"assets/images/users/user_1": "4867c30d8833b808fc3be3797af9e1e8"
};

// The application shell files that are downloaded before a service worker can
// start.
const CORE = [
  "/",
"main.dart.js",
"index.html",
"assets/NOTICES",
"assets/AssetManifest.json",
"assets/FontManifest.json"];
// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});

// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});

// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache.
        return response || fetch(event.request).then((response) => {
          cache.put(event.request, response.clone());
          return response;
        });
      })
    })
  );
});

self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});

// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}

// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
